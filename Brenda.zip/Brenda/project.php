<?php
    require_once('functions/manage.php');
    get_header();
?>
    <div class="page-breadcrumb bg-img space__bottom--r120" data-bg="assets/img/backgrounds/bc-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="page-breadcrumb-content text-center">
                        <h1>Project</h1>
                        <ul class="page-breadcrumb-links">
                            <li><a href="index.html">Home</a></li>
                            <li>Project</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--====================  End of breadcrumb area  ====================-->
    <div class="project-section space__bottom--r120">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="project-item-wrapper space__bottom--m40">
                        <div class="row">
                            <div class="col-lg-4 col-md-6 col-12 space__bottom--40">
                                <div class="single-project-wrapper single-project-wrapper--reduced-abs">
                                    <a class="single-project-item p-0" href="project-details.html">
                                        <img src="assets/img/projects/project1-m.jpg" class="img-fluid" alt="">
                                        <span class="single-project-title">Western Shopping Mall</span>
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-12 space__bottom--40">
                                <div class="single-project-wrapper single-project-wrapper--reduced-abs">
                                    <a class="single-project-item p-0" href="project-details.html">
                                        <img src="assets/img/projects/project2-m.jpg" class="img-fluid" alt="">
                                        <span class="single-project-title">City Flyover</span>
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-12 space__bottom--40">
                                <div class="single-project-wrapper single-project-wrapper--reduced-abs">
                                    <a class="single-project-item p-0" href="project-details.html">
                                        <img src="assets/img/projects/project3-m.jpg" class="img-fluid" alt="">
                                        <span class="single-project-title">Highway Carpeting</span>
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-12 space__bottom--40">
                                <div class="single-project-wrapper single-project-wrapper--reduced-abs">
                                    <a class="single-project-item p-0" href="project-details.html">
                                        <img src="assets/img/projects/project4-m.jpg" class="img-fluid" alt="">
                                        <span class="single-project-title">House Infrustructure Making</span>
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-12 space__bottom--40">
                                <div class="single-project-wrapper single-project-wrapper--reduced-abs">
                                    <a class="single-project-item p-0" href="project-details.html">
                                        <img src="assets/img/projects/project5-m.jpg" class="img-fluid" alt="">
                                        <span class="single-project-title">Wooden House</span>
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6 col-12 space__bottom--40">
                                <div class="single-project-wrapper single-project-wrapper--reduced-abs">
                                    <a class="single-project-item p-0" href="project-details.html">
                                        <img src="assets/img/projects/project6-m.jpg" class="img-fluid" alt="">
                                        <span class="single-project-title">Bridge Construction</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row space__top--50">
                <div class="col">
                    <ul class="page-pagination">
                        <li><a href="#"><i class="fa fa-angle-left"></i> Prev</a></li>
                        <li class="active"><a href="#">01</a></li>
                        <li><a href="#">02</a></li>
                        <li><a href="#">03</a></li>
                        <li><a href="#"><i class="fa fa-angle-right"></i> Next</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php
    get_footer();
?>
