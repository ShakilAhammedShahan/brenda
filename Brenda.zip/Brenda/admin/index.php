<?php
    require_once('functions/function.php');
    needLogged();
    get_header();
    get_sidebar();
?>
    Welcome Mr. Xyz
<?php
    get_footer();
?>
